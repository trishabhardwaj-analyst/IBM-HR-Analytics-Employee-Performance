# Interview Questions & Model Answers

### What metrics would you track to predict attrition risk?
I would track attrition rate, overtime, tenure, job satisfaction, work-life balance, business travel, distance from home, compensation, promotion history, job role and department. I would validate these signals statistically and operationally before using them for prediction.

### How would you present sensitive HR data responsibly?
I would aggregate results by department/role/cohort, suppress small groups, remove direct identifiers, explain limitations, and make it clear that analytics supports HR decisions rather than replacing human judgment.

### Correlation vs root cause?
Correlation indicates association. Root cause requires stronger evidence, such as longitudinal data, controls for confounding factors, experiments/quasi-experiments and process knowledge.

### Why use a date dimension if the IBM dataset has no dates?
The original IBM dataset is a static employee snapshot. For a date-enabled dashboard, I added clearly labeled derived HireDate, ApproxExitDate and SnapshotDate fields. These are not original historical facts.

### What is the main business recommendation?
Prioritize early-tenure and overtime-heavy populations for manager check-ins, workload review, career development and compensation benchmarking, while monitoring satisfaction and travel burden.
