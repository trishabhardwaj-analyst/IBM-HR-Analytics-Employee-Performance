# GitHub Upload Steps

1. Sign in to GitHub.
2. Click **New repository**.
3. Repository name: `IBM-HR-Analytics-Employee-Performance`.
4. Description: `HR analytics project using IBM HR Analytics Employee Attrition & Performance data with Excel, SQL and Power BI.`
5. Set Public if your internship requires a public portfolio repository.
6. Do **not** create another README if you are uploading this prepared README.
7. Create the repository.
8. Upload the entire contents of this project folder, preserving the folder structure.
9. Commit message: `Add IBM HR analytics attrition and performance project`.
10. After upload, click **Code → HTTPS → Copy** to copy the repository URL.

Example URL shape:
`https://github.com/YOUR-USERNAME/IBM-HR-Analytics-Employee-Performance`

Use that URL as the GitHub project link in the internship portal.
