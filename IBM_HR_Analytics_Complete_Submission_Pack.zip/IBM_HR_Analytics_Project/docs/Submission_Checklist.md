# Submission Checklist

- [x] Excel analysis workbook
- [x] Five attrition insights
- [x] Department-level performance summary
- [x] SQL analysis script
- [x] Power BI DAX + Power Query + theme + layout specification
- [x] Dashboard-ready screenshots
- [x] Complete PDF report
- [x] GitHub README
- [x] Data dictionary
- [x] Responsible HR reporting note

## Interview questions and model answers

### 1. What metrics would you track to predict attrition risk?
Attrition rate, overtime, tenure, job satisfaction, work-life balance, business travel, distance from home, compensation, promotion history, role and department. I would combine them in a risk model only after validating stability and fairness.

### 2. How would you present sensitive HR data responsibly?
Use aggregated cohorts, suppress small groups, avoid employee-level identifiers, explain uncertainty and correlation, and use the analysis to support—not automate—employment decisions.

### 3. Correlation vs root cause?
Correlation means two variables move together; root cause requires stronger evidence such as longitudinal data, experiments/quasi-experiments, process knowledge and controls for confounders.
