# Power BI Build Steps

## 1. Load EmployeeData
Power BI Desktop → Get Data → Text/CSV → `data/ibm_hr_date_enabled.csv`.

## 2. Load DateDimension
Get Data → Text/CSV → `data/date_dimension.csv`.

## 3. Data types
- EmployeeNumber: Whole number
- AttritionFlag: Whole number
- MonthlyIncome: Whole number
- PerformanceRating / satisfaction fields: Whole number
- HireDate / ApproxExitDate / SnapshotDate: Date

## 4. Relationship
Model view → DateDimension[Date] (1) → EmployeeData[HireDate] (*).

## 5. Measures
Create all measures in `powerbi/DAX_Measures.txt`.

## 6. Theme
View → Themes → Browse for themes → `powerbi/IBM_HR_Theme.json`.

## 7. Four pages
Follow `powerbi/Dashboard_Specification.md`.

## 8. Recommended slicers
Department, JobRole, OverTime, AgeGroup, TenureBand.

## 9. Responsible reporting
Do not show individual employee names/IDs to leadership. Use aggregate cohorts. The derived dates are analytical only.
