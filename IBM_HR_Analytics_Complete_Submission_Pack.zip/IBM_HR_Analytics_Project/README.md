# IBM HR Analytics & Employee Performance

## Project objective
Analyze workforce trends, department performance, salary distribution and employee attrition; identify practical drivers of attrition and summarize department-level performance.

## Dataset
The project follows the standard IBM HR Analytics Employee Attrition & Performance schema: 1,470 employees and 35 source fields. Public references describe the dataset as synthetic/hypothetical IBM HR data. The source schema itself has no actual date column. To satisfy the internship's date-enabled requirement, this repository includes a clearly labeled derived date layer (`HireDate`, `ApproxExitDate`, `SnapshotDate`).

## Deliverables
- `data/ibm_hr_standard_schema.csv` — 35-column IBM-compatible analysis table
- `data/ibm_hr_date_enabled.csv` — enriched table with derived date and analysis fields
- `data/date_dimension.csv` — Power BI date dimension
- `excel/IBM_HR_Analytics_Analysis.xlsx` — executive summary, department/role/tenure analyses, employee data, data dictionary
- `sql/hr_attrition_analysis.sql` — 12 business questions / SQL analyses
- `python/analysis.py` — repeatable analysis starter
- `powerbi/` — DAX, Power Query, theme and dashboard specification
- `screenshots/` — dashboard-ready charts
- `reports/IBM_HR_Analytics_Complete_Report.pdf` — final submission report

## Five key insights
1. Overtime is a major practical retention risk signal.
2. Short-tenure employees have materially higher attrition risk than long-tenure employees.
3. Junior/high-volume roles should receive targeted retention attention.
4. Lower satisfaction and work-life balance combine with other risk factors.
5. Performance rating alone is not a strong explanation of attrition; compensation, workload and experience should be reviewed together.

## Power BI
1. Open Power BI Desktop.
2. Import `data/ibm_hr_date_enabled.csv`.
3. Import `data/date_dimension.csv`.
4. Create a one-to-many relationship DateDimension[Date] -> EmployeeData[HireDate].
5. Add measures from `powerbi/DAX_Measures.txt`.
6. Apply `powerbi/IBM_HR_Theme.json`.
7. Build four pages from `powerbi/Dashboard_Specification.md`.

## GitHub
Create a repository named `IBM-HR-Analytics-Employee-Performance`. Upload the complete folder structure, then use the repository URL as the project link in the internship portal.

## Source reference
A public GitHub copy of the standard CSV was used as the schema reference: https://github.com/mrc03/IBM-HR-Analytics-Employee-Attrition-Performance

## Important note
This submission pack contains an IBM-schema-compatible analytical dataset generated for the project environment because the original public file was not directly available as an uploaded asset. The date-enabled fields are derived. If your internship portal requires the exact original 1,470-row source CSV, replace `data/ibm_hr_standard_schema.csv` with the original `WA_Fn-UseC_-HR-Employee-Attrition.csv` and rerun the analyses.
